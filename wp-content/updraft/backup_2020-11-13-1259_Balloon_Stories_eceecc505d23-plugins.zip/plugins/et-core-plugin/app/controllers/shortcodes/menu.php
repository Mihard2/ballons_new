<?php
namespace ETC\App\Controllers\Shortcodes;

use ETC\App\Controllers\Shortcodes;

/**
 * Menu shortcode.
 *
 * @since      1.4.4
 * @package    ETC
 * @subpackage ETC/Controllers/Shortcodes
 */
class Menu extends Shortcodes {

	function hooks() {}

	function menu_shortcode( $atts ) {
		
		$atts = shortcode_atts(array(
			'title' => '',
			'menu'  => '',
			'style' => '',
			'align' => '',
			'class' => '',
			'hide_submenus' => false,
			'submenu_side' => '',
			'submenu_side_vertical' => ''
		), $atts);

		$atts['class'] .= ' ' . $atts['style'];
		$atts['class'] .= ' menu-align-' . $atts['align'];

		if ( $atts['style'] == 'horizontal') 
			$atts['class'] .= (!empty($atts['submenu_side']) ) ? ' submenu-'.$atts['submenu_side'] : '';
		else 
			$atts['class'] .= (!empty($atts['submenu_side_vertical']) ) ? ' submenu-'.$atts['submenu_side_vertical'] : '';

		if ( $atts['hide_submenus'] ) 
			add_filter('menu_item_with_sublists', '__return_false');

		add_filter('menu_subitem_with_arrow', '__return_false');

		ob_start();

		?>

		<div class="menu-element <?php echo esc_attr($atts['class']); ?>">

			<?php if ( ! empty( $atts['title'] ) ) { ?>
				<h5><?php echo esc_html($atts['title']); ?></h5>
			<?php } ?>

			<?php 

			wp_nav_menu(
				array(
					'menu'				=>	$atts['menu'],
					'before' 			=>	'',
					'container_class'	=>	'',
					'after'				=>	'',
					'link_before'		=>	'',
					'link_after' 		=>	'',
					'depth' 			=>	( ( $atts['hide_submenus'] ) ? 1 : 100 ),
					'fallback_cb' 		=>	false,
					'walker' 			=>	new \ETheme_Navigation
				)
			);

			?>

		</div>

		<?php 

		remove_filter('menu_subitem_with_arrow', '__return_false');

		if ( $atts['hide_submenus'] )
			add_filter('menu_item_with_sublists', '__return_false');

		$output = ob_get_contents();
		
		ob_end_clean();

		return $output;

	}
}
