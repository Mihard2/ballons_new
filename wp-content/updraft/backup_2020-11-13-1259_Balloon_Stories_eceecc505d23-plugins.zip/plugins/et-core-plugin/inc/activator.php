<?php
namespace ETC\Inc;

/**
 * Fired during plugin activation.
 *
 * @since      1.4.4
 * @package    ETC
 * @subpackage ETC/includes
 */
class Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public function activate() {
	}

}
