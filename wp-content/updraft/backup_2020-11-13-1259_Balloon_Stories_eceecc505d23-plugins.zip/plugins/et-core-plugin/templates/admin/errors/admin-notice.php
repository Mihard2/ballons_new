<div class="error">

	<p><?php echo esc_html( $admin_notice ); ?></p>

</div>
