/*
 Theme Name:   <?php echo wp_filter_nohtml_kses($new_theme_title), "\n"; ?>
 Theme URI:    http://8theme.com/
 Description:  XStore Child Theme
 Author:       8theme
 Author URI:   http://8theme.com
 Template:     <?php echo wp_filter_nohtml_kses($new_theme_template), "\n"; ?>
 Version:      1.0
 Text Domain:  xstore-child
*/