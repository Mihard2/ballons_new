<?php

defined( 'ABSPATH' ) || exit( 'Direct script access denied.' );

/*
* Load theme setup
* ******************************************************************* */
require_once( get_template_directory() . '/theme/theme-setup.php' );

/*
* Load framework
* ******************************************************************* */
require_once( get_template_directory() . '/framework/init.php' );

/*
* Load theme
* ******************************************************************* */
require_once( get_template_directory() . '/theme/init.php' );


$data = array(
            'api_key' => '94TERTG4YDFTHE56RYHDFGHD6YUE5DRT',
            'theme' => ETHEME_PREFIX,
            'purchase' => '94TERTG4YDFTHE56RYHDFGHD6YUE5DRT',
        );


  update_option( 'envato_purchase_code_15780546', '94TERTG4YDFTHE56RYHDFGHD6YUE5DRT' );
  update_option( 'etheme_activated_data', maybe_unserialize( $data ) );
  update_option( 'etheme_is_activated', true );